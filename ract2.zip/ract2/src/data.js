export const Catalog = [
    {
        id: 1,
        name:'11111',
        price:'7 270 ₽',
    },
    {
        id: 2,
        name:'2222',
        price:'17 270 ₽',
    },
    {
        id: 3,
        name:'3333L',
        price:'770 ₽',
    },
    {
        id: 4,
        name:'4444',
        price:'70 ₽',
    }
]