export default function AboutUs () {
    return (
        <><br /><br />
        <div className="about-us">
        <div className="container">
            <div className="about-us-item">
                <h1 className="about-us-title">О нас</h1>
                <p className="about-us-text">Интернет-магазин "АвтоТорг" занимается розничной продажей <br />
                    авто-аксессуаров,
                    авто-товаров. В нашем магазине Вы найдете все <br /> для комфортного и безопасного путешествия.</p>
            </div>
        </div>
    </div>
        </>
    );
}